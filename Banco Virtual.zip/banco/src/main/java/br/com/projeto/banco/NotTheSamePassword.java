package br.com.projeto.banco;

public class NotTheSamePassword extends Exception {

	public NotTheSamePassword() {
		// TODO Auto-generated constructor stub
	}
}