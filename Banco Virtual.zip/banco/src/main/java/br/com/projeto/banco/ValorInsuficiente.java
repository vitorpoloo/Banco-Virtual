package br.com.projeto.banco;

public class ValorInsuficiente extends Exception
{
	public ValorInsuficiente() {
		// TODO Auto-generated constructor stub
	}

}